#Import the random module as rnd and generate a random integer between 1 and 100.
#● Import the math module and calculate the square root of 49 and the sine of 90 degrees (convert degrees to radians using math.radians).

import random as rnd

random_number = rnd.randint(1, 100)
print("Random number between 1 and 100:", random_number)

import math

sqrt_49 = math.sqrt(49)
sine_90 = math.sin(math.radians(90))

print("Square root of 49:", sqrt_49)
print("Sine of 90 degrees:", sine_90)

