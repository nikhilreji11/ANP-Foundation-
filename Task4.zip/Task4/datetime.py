#Create a program that greets the user based on the current time (e.g., "Good
#Morning" before noon, "Good Afternoon" in the afternoon, and "Good Evening" in the
#evening). Use the datetime module to retrieve the current time and conditionally display a greeting.

from datetime import datetime

current_hour = datetime.now().hour

if current_hour < 12:
    greeting = "Good Morning!"
elif 12 <= current_hour < 18:
    greeting = "Good Afternoon!"
else:
    greeting = "Good Evening!"

print(greeting)
