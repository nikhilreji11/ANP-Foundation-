import finance

monthly_income = finance.calculate_income(50000, 2000)  
monthly_expenses = finance.calculate_expenses(12000, 8000, 2000) 

savings = finance.calculate_savings(monthly_income, monthly_expenses)
percent_saved = finance.savings_percentage(monthly_income, savings)

print(f"Total Income: ₹{monthly_income}")
print(f"Total Expenses: ₹{monthly_expenses}")
print(f"Savings: ₹{savings}")
print(f"Savings Percentage: {percent_saved:.2f}%")
