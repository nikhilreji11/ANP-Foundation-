#Imagine you are developing a personal finance tracking application. Create a custom module named finance.py that includes functions for calculating expenses, income, and savings. Describe the functions you would include and how you would import this module in your main application.


def calculate_expenses(*expenses):
    """Returns the total expenses."""
    return sum(expenses)

def calculate_income(*incomes):
    """Returns the total income."""
    return sum(incomes)

def calculate_savings(income, expenses):
    """Returns the savings by subtracting expenses from income."""
    return income - expenses

def savings_percentage(income, savings):
    """Returns the percentage of income saved."""
    if income == 0:
        return 0
    return (savings / income) * 100
