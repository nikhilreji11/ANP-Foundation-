#Write a Python program that asks the user to input two dates (in YYYY-MM-DD format) and calculates the number of days between the two dates. Use the datetime module to perform the calculation.

from datetime import datetime

date1_str = input("Enter the first date (YYYY-MM-DD): ")
date2_str = input("Enter the second date (YYYY-MM-DD): ")

try:
    date1 = datetime.strptime(date1_str, "%Y-%m-%d")
    date2 = datetime.strptime(date2_str, "%Y-%m-%d")

    difference = abs((date2 - date1).days)

    print(f"The number of days between the two dates is: {difference} days")
except ValueError:
    print("Invalid date format. Please enter dates in YYYY-MM-DD format.")
