#Create a custom module named my_calculations.py with functions for addition
#and subtraction. Import this module in a separate script and use the functions.
#● Import only the pi constant from the math module and use it to calculate the area
#of a circle with radius 7.
#● Import the log function from the math module as logarithm and compute the
#natural log of 10.


def add(a, b):
    return a + b

def subtract(a, b):
    return a - b
