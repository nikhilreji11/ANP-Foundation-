from my_calculations import add, subtract
from math import pi
from math import log as logarithm

print("Addition:", add(10, 5))          
print("Subtraction:", subtract(10, 5))  

radius = 7
area = pi * (radius ** 2)
print("Area of circle with radius 7:", area)  

print("Natural log of 10:", logarithm(10))    
